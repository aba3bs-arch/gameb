# Mi tragamonedas

Abre `index.html` para inspeccionar juntos los 3 bocetos. Cada SVG y PNG también está guardado por separado.
